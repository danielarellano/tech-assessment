﻿using System;
using System.Collections.Generic;
using System.Linq;
using CSharp.OrderDetails;
using CSharp.Repository;
using System.Threading.Tasks;

namespace CSharp.Service
{
    public class OrderService
    {
        OrderRepository _orderRepo = new OrderRepository();
        public Guid CreateOrder(string customerName, List<string> orders, int amount)
        {
            var newOrder = new Order()
            {
                CustomerName = customerName,
                Orders = orders,
                Amount = amount
            };
            _orderRepo.orders.Add(newOrder);
            return newOrder.CustomerId;
        }

        public List<Order> GetOrdersByCustomer(string customerName)
        {
            return _orderRepo.orders.Where(c => c.CustomerName == customerName).ToList();
        }

        public void CancelOrder(Guid CustomerId)
        {
            var cancelOrder = _orderRepo.orders.Where(c => c.CustomerId == CustomerId).FirstOrDefault();
            if (cancelOrder != null)
            {
                _orderRepo.orders.Remove(cancelOrder);
                return;
            }
            return;
        }

        public void UpdateOrder(Guid customerId, string customerName, List<string> orders, int amount)
        {
            var updateOrder = _orderRepo.orders.Where(c => c.CustomerId == customerId).FirstOrDefault();
            if (updateOrder != null)
            {
                updateOrder.CustomerId = customerId;
                updateOrder.CustomerName = customerName;
                updateOrder.Orders = orders;
                updateOrder.Amount = amount;
                return;
            }
            return;
        }
    }
}
