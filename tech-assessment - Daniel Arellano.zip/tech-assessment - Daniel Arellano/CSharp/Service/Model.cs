﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp.Service
{
    public class Model
    {
        public class CreateOrderModel
        {
            public string customerName { get; set; }
            public List<string> orders { get; set; }
            public int amount { get; set; }

        }
        public class UpdateOrderModel
        {
            public Guid id { get; set; }
            public string customerName { get; set; }
            public List<string> orders { get; set; }
            public int amount { get; set; }

        }
    }
}
