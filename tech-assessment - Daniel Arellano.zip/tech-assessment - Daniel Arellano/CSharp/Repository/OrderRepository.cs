﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharp.OrderDetails;

namespace CSharp.Repository
{
    public class OrderRepository
    {
        private static List<Order> _orders = new List<Order>()
        {
            new Order() {
                CustomerId = Guid.Parse("d13b2e5w-15d3-b8w4-3h93-qa5p4cvbm85z"),
                CustomerName = "Daniel",
                Orders = {"Dresser","Couch", "Lamp"},
                Amount = 109
             },
            new Order() {
                CustomerId = Guid.Parse("d13b2e5w-15d3-q1p4-3h93-qa5p4cvbm85z"),
                CustomerName = "Jameline",
                Orders = {"Desk"},
                Amount = 75
            },
              new Order() {
                CustomerId = Guid.Parse("d13b2e5w-15d3-v863-3h93-qa5p4cvbm85z"),
                CustomerName = "Sergio",
                Orders = {"Shelves", "Batteries"},
                Amount = 47
            },
              new Order() {
                CustomerId = Guid.Parse("d13b2e5w-15d3-d3r6-3h93-qa5p4cvbm85z"),
                CustomerName = "Melissa",
                Orders = {"Mattress", "BedFrame", "Pillow"},
                Amount = 140
            },
        };
        public List<Order> orders
        {
            get { return _orders; }
            set { _orders = value; }
        }

    }
}
