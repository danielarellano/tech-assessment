﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp.OrderDetails
{
    public class Order
    {
        public Guid CustomerId { get; set; }
        public string CustomerName { get; set; }
        public List<string> Orders { get; set; }
        public int Amount { get; set; }
    }
}
