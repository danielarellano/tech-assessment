﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharp.Service;
using Microsoft.AspNetCore.Mvc;

namespace CSharp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private OrderService _orderService = new OrderService();

        [HttpGet]
        [Route("{customer}")]
        public void GetOrdersByCustomer(string customer)
        {
            _orderService.GetOrdersByCustomer(customer);
        }

        [HttpPost]
        public Guid CreateOrder([FromBody] Model.CreateOrderModel createOrderModel)
        {
            var orderId = _orderService.CreateOrder(createOrderModel.customerName, createOrderModel.orders, createOrderModel.amount);
            return orderId;
        }

        [HttpPost]
        [Route("update")]
        public void UpdateOrder([FromBody] Model.UpdateOrderModel updateOrderModel)
        {
            _orderService.UpdateOrder(updateOrderModel.id, updateOrderModel.customerName, updateOrderModel.orders, updateOrderModel.amount);
        }

        [HttpPost]
        [Route("cancel/{orderId}")]
        public void CancelOrder(Guid orderId)
        {
            _orderService.CancelOrder(orderId);
        }
    }
}
