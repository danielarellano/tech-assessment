﻿using CSharp.Repository;
using CSharp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp.Tests
{
    public class OrderTests
    {
        public OrderService _orderService = new OrderService();
        public OrderRepository _orderRepo = new OrderRepository();

        [Fact]
        public void CreateOrderTest()
        {
            var customerName = "Michael";
            var orders = new List<string>() { "Dresser", "Couch", "Lamp" };
            var amount = 109;

            var orderId = _orderService.CreateOrder(customerName, orders, amount);
            var createOrder = _orderRepo.orders.Where(c => c.CustomerId == orderId);

            Assert.Equal(customerName, createOrder.CustomerName);
            Assert.Equal(orders, createOrder.Orders);
            Assert.Equal(amount, createOrder.Amount);
        }

    }
}
